from Product import Product
"""
Aqui se encuentran definidas las clases que heredan de la abstraccion
Products
"""


class UselessProduct(Product):
    pass


class CommonProduct(Product):
    pass


class RareProduct(Product):
    pass


class LegendaryProduct(Product):
    pass
