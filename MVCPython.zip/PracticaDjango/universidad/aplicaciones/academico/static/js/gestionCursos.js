(function () {
    const btnEliminacionArray = document.querySelectorAll(".btnEliminacion");

    btnEliminacionArray.forEach(btn => {
        btn.addEventListener("click", (e) => {
            const confirmacion = confirm("Seguro de eliminar el curso?");
            if (!confirmacion) {
                e.preventDefault();
            }
        });
    });
})();