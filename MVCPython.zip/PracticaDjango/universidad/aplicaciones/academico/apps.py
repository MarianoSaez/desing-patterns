from django.apps import AppConfig


class AcademicoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    # Fue necesario corregir el dotted path en el name
    # name = 'academico'
    name = 'aplicaciones.academico'
