from django.shortcuts import render, redirect
from .models import Curso
from django.contrib import messages

# Create your views here.

def home(req):
    cursosListados = Curso.objects.all()
    messages.success(req, "Cursos listados!")
    return render(req, "gestionCursos.html", {"cursos" : cursosListados})

def registrarCurso(req):
    codigo = req.POST['txtCodigo']
    nombre = req.POST['txtNombre']
    creditos = req.POST['numCreditos']

    curso = Curso.objects.create(codigo=codigo, nombre=nombre, creditos=creditos)

    return redirect('/')

def eliminarCurso(req, code):
    curso = Curso.objects.get(codigo=code)
    curso.delete()
    return redirect('/')

def edicionCurso(req, code):
    curso = Curso.objects.get(codigo=code)
    return render(req, "edicionCurso.html", {"curso" : curso})

def guardarEdicionCurso(req):
    codigo = req.POST['txtCodigo']
    nombre = req.POST['txtNombre']
    creditos = req.POST['numCreditos']

    curso = Curso.objects.get(codigo=codigo)

    curso.nombre = nombre
    curso.creditos = creditos

    curso.save()

    return redirect('/')

     