from django.urls import path
from . import views


urlpatterns = [
    path('', views.home),
    path('registrarCurso/', views.registrarCurso),
    path('eliminarCurso/<code>', views.eliminarCurso),
    path('edicionCurso/<code>', views.edicionCurso),
    path('guardarEdicionCurso/', views.guardarEdicionCurso)
]